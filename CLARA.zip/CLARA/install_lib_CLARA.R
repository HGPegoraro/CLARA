options(timeout = 300)

pacots <- c("shiny", "shinyjs", "readxl", "DT", "ggplot2", "dplyr", "jsonlite", "ggtext", "shinyWidgets", "digest", "tibble", "tidyr", "ggpattern", "emmeans", "multcomp", "multcompView", "sortable", "commonmark", "fBasics")
install.packages(pacots, repos = "https://cran.rstudio.com/",dependencies = TRUE)